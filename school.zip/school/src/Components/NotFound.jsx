import React from "react";

const NotFound = () => {
    return <h1>یافت نشد.</h1>;
};

export default NotFound;
